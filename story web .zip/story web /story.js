// script.js — uses module-style (vanilla JS). No frameworks, no server required.
const STORAGE_KEYS = {
  STORIES: 'mt_stories_v1',
  FAVS: 'mt_favs_v1',
  AGE_PASS: 'mt_age_pass_v1',
  THEME: 'mt_theme_v1'
};

// Sample stories (non-explicit placeholders). Replace or import via admin.
const DEFAULT_STORIES = [
  {
    id: "s1",
    title: "The Last Train Home",
    author: "M. Alvarez",
    category: "Drama",
    excerpt: "A rainy platform, a lost ticket, two strangers who share a single moment.",
    content: `It was the kind of rain that blurred signboards into pale ghosts. Maya clutched the paper ticket so tightly the edges softened. Across the tracks, a man in a wrinkled coat watched as if waiting for someone the rain had already taken. They said nothing at first. Conversation arrived like a late train — hesitant, then certain...`,
    created: "2024-09-02",
    views: 152
  },
  {
    id: "s2",
    title: "After Midnight",
    author: "R. Olu",
    category: "Romance",
    excerpt: "Two neighbors find a note at midnight — and their lives begin to change.",
    content: `Samira found the note folded under her door at 00:12. The handwriting was small and precise: 'If you are awake, look at the balcony.' She laughed and peered out. There, under the dim cast of the streetlamp, someone had left a jasmine sprig and a teacup. It was the start of many small gestures that became...`,
    created: "2025-03-18",
    views: 220
  },
  {
    id: "s3",
    title: "A Quiet Confession",
    author: "Julian Cross",
    category: "Literary",
    excerpt: "He writes letters he never sends — until the day he decides to mail them all.",
    content: `He kept the letters in a shoebox near the radiator, each one a careful unbraiding of regret. On a Thursday, when the city smelled of cut grass, he walked to the post office and bought stamps. Sending them felt less like confession and more like a small exhale.`,
    created: "2025-01-10",
    views: 89
  }
];

// App state
let state = {
  stories: [],
  filtered: [],
  current: null,
  page: 1,
  perPage: 6,
  favorites: new Set(),
  theme: localStorage.getItem(STORAGE_KEYS.THEME) || 'light'
};

// Elements
const qs = s => document.querySelector(s);
const qsa = s => Array.from(document.querySelectorAll(s));

const ageGate = qs('#age-gate');
const enterBtn = qs('#enterBtn');
const leaveBtn = qs('#leaveBtn');
const agePassInput = qs('#agePass');
const setPassBtn = qs('#setPassBtn');

const searchInput = qs('#searchInput');
const storiesGrid = qs('#storiesGrid');
const categoryList = qs('#categoryList');
const favsBtn = qs('#favoritesBtn');
const darkModeBtn = qs('#darkModeBtn');
const perPageSelect = qs('#perPage');
const sortSelect = qs('#sortSelect');
const filterFavorites = qs('#filterFavorites');

const reader = qs('#reader');
const listView = qs('#listView');
const backToList = qs('#backToList');
const storyMeta = qs('#storyMeta');
const storyContent = qs('#storyContent');
const fontSizeRange = qs('#fontSize');
const favToggle = qs('#favToggle');
const downloadBtn = qs('#downloadBtn');
const prevStory = qs('#prevStory');
const nextStory = qs('#nextStory');

const importFile = qs('#importFile');
const exportBtn = qs('#exportBtn');
const clearDataBtn = qs('#clearDataBtn');
const yearSpan = qs('#year');

yearSpan.textContent = new Date().getFullYear();

/* --- Initialization --- */
function loadStories(){
  const raw = localStorage.getItem(STORAGE_KEYS.STORIES);
  if(raw){
    try{
      state.stories = JSON.parse(raw);
    }catch(e){
      console.error('Failed to parse stories:', e);
      state.stories = DEFAULT_STORIES.slice();
    }
  } else {
    state.stories = DEFAULT_STORIES.slice();
    localStorage.setItem(STORAGE_KEYS.STORIES, JSON.stringify(state.stories));
  }
}

function loadFavs(){
  try{
    const raw = localStorage.getItem(STORAGE_KEYS.FAVS) || '[]';
    JSON.parse(raw).forEach(id => state.favorites.add(id));
  }catch(e){
    console.error(e);
    state.favorites = new Set();
  }
}

function saveFavs(){
  localStorage.setItem(STORAGE_KEYS.FAVS, JSON.stringify(Array.from(state.favorites)));
}

/* Theme */
function applyTheme(){
  document.documentElement.setAttribute('data-theme', state.theme === 'dark' ? 'dark' : 'light');
  localStorage.setItem(STORAGE_KEYS.THEME, state.theme);
}
darkModeBtn.addEventListener('click', () => {
  state.theme = state.theme === 'dark' ? 'light' : 'dark';
  applyTheme();
});

/* Age gate */
enterBtn.addEventListener('click', () => {
  ageGate.classList.remove('active');
  ageGate.setAttribute('aria-hidden', 'true');
});
leaveBtn.addEventListener('click', () => {
  // redirect away
  window.location.href = "about:blank";
});
setPassBtn.addEventListener('click', () => {
  const v = agePassInput.value.trim();
  if(!v) return alert('Enter a passcode to save.');
  localStorage.setItem(STORAGE_KEYS.AGE_PASS, v);
  alert('Passcode saved locally. Keep it secret.');
});

/* If passcode set, skip gate */
if(localStorage.getItem(STORAGE_KEYS.AGE_PASS)){
  ageGate.classList.remove('active');
  ageGate.setAttribute('aria-hidden','true');
}

/* Load data */
loadStories();
loadFavs();
applyTheme();

/* Derived lists and UI */
function getCategories(){
  const cats = new Set(state.stories.map(s => s.category || 'Uncategorized'));
  return Array.from(cats).sort();
}

function renderCategories(){
  categoryList.innerHTML = '';
  const all = document.createElement('li');
  all.innerHTML = `<button class="btn ghost small" data-cat="">All</button>`;
  categoryList.appendChild(all);
  getCategories().forEach(cat => {
    const li = document.createElement('li');
    li.innerHTML = `<button class="btn small" data-cat="${cat}">${cat}</button>`;
    categoryList.appendChild(li);
  });

  categoryList.querySelectorAll('button').forEach(btn => {
    btn.addEventListener('click', (e)=>{
      const cat = e.currentTarget.dataset.cat;
      searchInput.value = '';
      applyFilters({category:cat});
    });
  });
}

/* Filtering / Searching */
function applyFilters({category = null} = {}){
  const q = searchInput.value.trim().toLowerCase();
  let list = state.stories.slice();

  if(category){
    list = list.filter(s => (s.category || '').toLowerCase() === category.toLowerCase());
  }
  if(q){
    list = list.filter(s => (s.title + ' ' + s.author + ' ' + s.excerpt + ' ' + (s.content||'')).toLowerCase().includes(q));
  }
  if(filterFavorites.checked){
    list = list.filter(s => state.favorites.has(s.id));
  }

  // Sorting
  const sort = sortSelect.value;
  if(sort === 'new'){
    list.sort((a,b)=> new Date(b.created) - new Date(a.created));
  } else if(sort === 'popular'){
    list.sort((a,b)=> (b.views||0) - (a.views||0));
  } else if(sort === 'alpha'){
    list.sort((a,b)=> a.title.localeCompare(b.title));
  }

  state.filtered = list;
  state.page = 1;
  renderStories();
}

/* Rendering stories grid */
function renderStories(){
  const perPage = parseInt(perPageSelect.value || state.perPage,10);
  state.perPage = perPage;
  const start = (state.page - 1) * perPage;
  const pageItems = state.filtered.slice(start, start + perPage);

  storiesGrid.innerHTML = '';
  if(pageItems.length === 0){
    storiesGrid.innerHTML = `<p class="small">No stories found.</p>`;
  } else {
    const tpl = document.getElementById('storyCardTemplate');
    pageItems.forEach(story => {
      const clone = tpl.content.cloneNode(true);
      const card = clone.querySelector('.card');
      clone.querySelector('.card-title').textContent = story.title;
      clone.querySelector('.card-excerpt').textContent = story.excerpt;
      clone.querySelector('.author').textContent = story.author || 'Unknown';
      clone.querySelector('.time').textContent = new Date(story.created).toLocaleDateString();
      const readBtn = clone.querySelector('.readBtn');
      const favBtn = clone.querySelector('.favBtn');

      readBtn.addEventListener('click', ()=> openStory(story.id));
      favBtn.addEventListener('click', ()=>{
        toggleFavorite(story.id);
        favBtn.textContent = state.favorites.has(story.id) ? '★' : '☆';
        favBtn.classList.toggle('active', state.favorites.has(story.id));
      });
      favBtn.textContent = state.favorites.has(story.id) ? '★' : '☆';
      storiesGrid.appendChild(clone);
    });
  }
  renderPagination();
}

/* Pagination */
function renderPagination(){
  const perPage = state.perPage;
  const total = state.filtered.length;
  const pages = Math.max(1, Math.ceil(total / perPage));
  const container = qs('#pagination');
  container.innerHTML = '';

  for(let i=1;i<=pages;i++){
    const btn = document.createElement('button');
    btn.className = 'btn small';
    btn.textContent = i;
    if(i === state.page) btn.classList.add('primary');
    btn.addEventListener('click', ()=> {
      state.page = i; renderStories();
      window.scrollTo({top:0,behavior:'smooth'});
    });
    container.appendChild(btn);
  }
}

/* Open story in reader */
function openStory(id){
  const story = state.stories.find(s => s.id === id);
  if(!story) return;
  state.current = story;
  // increment views (client-side only)
  story.views = (story.views||0) + 1;
  localStorage.setItem(STORAGE_KEYS.STORIES, JSON.stringify(state.stories));

  listView.classList.add('hidden');
  reader.classList.remove('hidden');

  storyMeta.innerHTML = `<h2>${story.title}</h2><div class="small">By ${story.author || 'Unknown'} • ${story.category || 'Uncategorized'} • ${new Date(story.created).toLocaleDateString()}</div>`;
  storyContent.textContent = story.content;
  storyContent.style.fontSize = fontSizeRange.value + 'px';
  favToggle.textContent = state.favorites.has(id) ? '★ Favorited' : '☆ Favorite';
}

/* Back to list */
backToList.addEventListener('click', ()=> {
  reader.classList.add('hidden');
  listView.classList.remove('hidden');
  state.current = null;
  applyFilters();
});

/* Favorites */
function toggleFavorite(id){
  if(state.favorites.has(id)) state.favorites.delete(id);
  else state.favorites.add(id);
  saveFavs();
}

/* Fav button in topbar shows favorites view */
favsBtn.addEventListener('click', ()=> {
  filterFavorites.checked = true;
  applyFilters();
  window.scrollTo({top:0,behavior:'smooth'});
});

favToggle.addEventListener('click', ()=>{
  if(!state.current) return;
  toggleFavorite(state.current.id);
  favToggle.textContent = state.favorites.has(state.current.id) ? '★ Favorited' : '☆ Favorite';
});

/* Font size control */
fontSizeRange.addEventListener('input', () => {
  storyContent.style.fontSize = fontSizeRange.value + 'px';
});

/* Download current story as text file */
downloadBtn.addEventListener('click', ()=>{
  if(!state.current) return;
  const blob = new Blob([`${state.current.title}\nBy ${state.current.author}\n\n${state.current.content}`], {type:'text/plain'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${state.current.title.replace(/[^\w\d]+/g,'_').slice(0,40)}.txt`;
  document.body.appendChild(a); a.click(); a.remove();
  URL.revokeObjectURL(url);
});

/* Prev / Next story navigation (in filtered list) */
prevStory.addEventListener('click', ()=> {
  if(!state.current) return;
  const idx = state.filtered.findIndex(s => s.id === state.current.id);
  if(idx > 0) openStory(state.filtered[idx-1].id);
});
nextStory.addEventListener('click', ()=> {
  if(!state.current) return;
  const idx = state.filtered.findIndex(s => s.id === state.current.id);
  if(idx < state.filtered.length - 1) openStory(state.filtered[idx+1].id);
});

/* Events */
searchInput.addEventListener('input', debounce(()=> applyFilters(), 250));
perPageSelect.addEventListener('change', ()=> applyFilters());
sortSelect.addEventListener('change', ()=> applyFilters());
filterFavorites.addEventListener('change', ()=> applyFilters());

/* Import / Export */
exportBtn.addEventListener('click', ()=>{
  const data = JSON.stringify(state.stories, null, 2);
  const blob = new Blob([data], {type:'application/json'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = 'moonlight-stories.json';
  document.body.appendChild(a); a.click(); a.remove();
  URL.revokeObjectURL(url);
});

importFile.addEventListener('change', (e)=>{
  const f = e.target.files[0];
  if(!f) return;
  const reader = new FileReader();
  reader.onload = (ev) => {
    try{
      const arr = JSON.parse(ev.target.result);
      if(!Array.isArray(arr)) throw new Error('Invalid format: expected array');
      // Basic validation
      arr.forEach(s => {
        if(!s.id) s.id = generateId();
        if(!s.title) s.title = 'Untitled Story';
        if(!s.created) s.created = new Date().toISOString().slice(0,10);
      });
      state.stories = arr;
      localStorage.setItem(STORAGE_KEYS.STORIES, JSON.stringify(state.stories));
      alert('Imported stories locally.');
      loadInitialUI();
    }catch(err){
      alert('Import failed: ' + err.message);
    }
  };
  reader.readAsText(f);
  importFile.value = '';
});

clearDataBtn.addEventListener('click', ()=>{
  if(!confirm('This will reset local stories and favorites to defaults. Continue?')) return;
  localStorage.removeItem(STORAGE_KEYS.STORIES);
  localStorage.removeItem(STORAGE_KEYS.FAVS);
  location.reload();
});

/* Helpers */
function generateId(){ return 's_' + Math.random().toString(36).slice(2,9); }
function debounce(fn, ms=200){ let t; return (...a)=>{ clearTimeout(t); t=setTimeout(()=>fn(...a), ms); }; }

/* Initial render */
function loadInitialUI(){
  renderCategories();
  applyFilters();
}
loadInitialUI();

/* Accessibility: keyboard nav for story cards (delegated) */
storiesGrid.addEventListener('keydown', (e)=>{
  if(e.key === 'Enter'){
    const btn = e.target.closest('.readBtn');
    if(btn) btn.click();
  }
});

/* Click home resets filters */
qs('#homeLink').addEventListener('click', (e)=>{
  e.preventDefault();
  searchInput.value = '';
  filterFavorites.checked = false;
  applyFilters();
});

/* On load: parse URL hash to open a story by id (#s1) */
window.addEventListener('hashchange', ()=> {
  const id = location.hash.slice(1);
  if(id) openStory(id);
});
const initialHash = location.hash.slice(1);
if(initialHash){
  // delay to ensure UI loaded
  setTimeout(()=> openStory(initialHash), 300);
}